"use strict";
(() => {
var exports = {};
exports.id = 671;
exports.ids = [671];
exports.modules = {

/***/ 555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 17:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 13:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "i": () => (/* binding */ dirExists),
  "h": () => (/* binding */ execute)
});

// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(147);
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(17);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
;// CONCATENATED MODULE: external "child_process"
const external_child_process_namespaceObject = require("child_process");
;// CONCATENATED MODULE: ./common/misc.ts



function execute(command, { stdout , stderr , ...options } = {}) {
    return new Promise((resolve, reject)=>{
        const child = external_child_process_namespaceObject.exec(command, options, (error, stdout, stderr)=>{
            if (error) return reject(error.code ? new Error(stderr) : error);
            resolve(stdout);
        });
        if (child.stdout && stdout) child.stdout.pipe(stdout);
        if (child.stderr && stderr) child.stderr.pipe(stderr);
    });
}
/**
 * 读取路径信息
 * @param {string} path 路径
 */ function getStat(path) {
    return new Promise((resolve)=>{
        external_fs_default().stat(path, (err, stats)=>{
            if (err) {
                resolve(false);
            } else {
                resolve(stats);
            }
        });
    });
}
/**
 * 创建路径
 * @param {string} dir 路径
 */ function mkdir(dir) {
    return new Promise((resolve)=>{
        external_fs_default().mkdir(dir, (err)=>{
            if (err) {
                resolve(false);
            } else {
                resolve(true);
            }
        });
    });
}
/**
 * 路径是否存在，不存在则创建
 * @param {string} dir 路径
 */ async function dirExists(dir) {
    let isExists = await getStat(dir);
    //如果该路径且不是文件，返回true
    if (isExists && isExists.isDirectory()) {
        return true;
    } else if (isExists) {
        //如果该路径存在但是文件，返回false
        return false;
    }
    //如果该路径不存在
    let tempDir = external_path_default().parse(dir).dir; //拿到上级路径
    //递归判断，如果上级目录也不存在，则会代码会在此处继续循环执行，直到目录存在
    let status = await dirExists(tempDir);
    let mkdirStatus;
    if (status) {
        mkdirStatus = await mkdir(dir);
    }
    return mkdirStatus;
}


/***/ }),

/***/ 374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(555);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(837);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(657);
/* harmony import */ var common_misc__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(13);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_2__]);
uuid__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction






async function handler(req, res) {
    try {
        const dir = path__WEBPACK_IMPORTED_MODULE_1___default().resolve("tmp", (0,uuid__WEBPACK_IMPORTED_MODULE_2__.v4)().replaceAll("-", ""));
        await (0,common_misc__WEBPACK_IMPORTED_MODULE_4__/* .dirExists */ .i)(dir);
        await (0,util__WEBPACK_IMPORTED_MODULE_3__.promisify)((fs__WEBPACK_IMPORTED_MODULE_0___default().writeFile))(path__WEBPACK_IMPORTED_MODULE_1___default().join(dir, "main.cpp"), req.body.code);
        await (0,common_misc__WEBPACK_IMPORTED_MODULE_4__/* .execute */ .h)(`cd ${dir} && g++ main.cpp -o Main -O2 -std=c++11 -lcurl -B "/var/empty/local" && ALGORITHM_VISUALIZER=1 ./Main`);
        const commands = await (0,util__WEBPACK_IMPORTED_MODULE_3__.promisify)((fs__WEBPACK_IMPORTED_MODULE_0___default().readFile))(path__WEBPACK_IMPORTED_MODULE_1___default().join(dir, "visualization.json"), {
            encoding: "utf-8"
        });
        setTimeout(()=>{
            (0,common_misc__WEBPACK_IMPORTED_MODULE_4__/* .execute */ .h)(`rm -rf ${dir}`);
        }, 66);
        res.status(200).json(JSON.parse(commands));
    } catch (error) {
        res.status(404).json({
            error: (0,utils__WEBPACK_IMPORTED_MODULE_5__/* .errorToJSON */ .L)(error)
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ errorToJSON)
/* harmony export */ });
function errorToJSON(error) {
    return {
        ...JSON.parse(JSON.stringify(error, Object.getOwnPropertyNames(error)))
    };
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(374));
module.exports = __webpack_exports__;

})();