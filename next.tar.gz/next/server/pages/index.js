"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ index_page),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_namespaceObject);
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: external "util"
const external_util_namespaceObject = require("util");
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(725);
// EXTERNAL MODULE: ./common/util.js
var util = __webpack_require__(223);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "ahooks"
var external_ahooks_ = __webpack_require__(398);
;// CONCATENATED MODULE: ./pages/index.page.tsx









const { DirectoryTree  } = external_antd_.Tree;
const { Title , Paragraph , Text  } = external_antd_.Typography;
function generateTreeData(data) {
    return data.map((item)=>{
        if (item.children) {
            item.children = generateTreeData(item.children.filter((file)=>{
                if (file.type === "file") {
                    const ext = (0,util/* extension */.AO)(file.title);
                    return [
                        "cpp",
                        "js"
                    ].includes(ext);
                }
                return true;
            }));
        }
        return item;
    });
}
async function generateTree(root) {
    const filesNameArr = [];
    // 用个hash队列保存每个目录的深度
    const mapDeep = {};
    mapDeep[root] = 0;
    // 先遍历一遍给其建立深度索引
    async function getMap(dir, curIndex) {
        const files = await (0,external_util_namespaceObject.promisify)((external_fs_default()).readdir)(dir); //同步拿到文件目录下的所有文件名
        for (const file of files){
            //const subPath = path.resolve(dir, file) //拼接为绝对路径
            const subPath = external_path_default().join(dir, file); //拼接为相对路径
            const stats = await (0,external_util_namespaceObject.promisify)((external_fs_default()).stat)(subPath); //拿到文件信息对象
            // 必须过滤掉node_modules文件夹
            if (file != "node_modules") {
                mapDeep[file] = curIndex + 1;
                if (stats.isDirectory()) {
                    //判断是否为文件夹类型
                    await getMap(subPath, mapDeep[file]); //递归读取文件夹
                }
            }
        }
    }
    await getMap(root, mapDeep[root]);
    async function readdirs(dir, folderName, myroot) {
        const result = {
            //构造文件夹数据
            path: dir,
            key: dir.replace(root, ""),
            title: external_path_default().basename(dir),
            type: "directory",
            deep: mapDeep[folderName]
        };
        //同步拿到文件目录下的所有文件名
        const files = (await (0,external_util_namespaceObject.promisify)((external_fs_default()).readdir)(dir)).filter((file)=>file.indexOf(".") !== 0);
        result.children = [];
        for(let index = 0; index < files.length; index++){
            const file = files[index];
            //const subPath = path.resolve(dir, file) //拼接为绝对路径
            const subPath = external_path_default().join(dir, file); //拼接为相对路径
            const stats = await (0,external_util_namespaceObject.promisify)((external_fs_default()).stat)(subPath); //拿到文件信息对象
            if (stats.isDirectory()) {
                //判断是否为文件夹类型
                result.children[index] = await readdirs(subPath, file, file); //递归读取文件夹
            } else {
                result.children[index] = {
                    //构造文件数据
                    path: subPath,
                    key: subPath.replace(root, ""),
                    title: file,
                    type: "file"
                };
            }
        }
        if (!result.children.length) {
            delete result.children;
        }
        return result; //返回数据
    }
    filesNameArr.push(await readdirs(root, root));
    return generateTreeData(filesNameArr);
}
const getServerSideProps = async function(context) {
    const dir = external_path_default().resolve("algorithms");
    const treeData = await generateTree(dir);
    return {
        props: {
            ready: true,
            treeData
        }
    };
};
const Home = ({ treeData  })=>{
    const router = (0,router_.useRouter)();
    const ref = (0,external_react_.useRef)(null);
    const size = (0,external_ahooks_.useSize)(ref);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-full flex flex-col pt-10 px-10 pb-3",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Typography, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Title, {
                        children: "算法可视化"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Paragraph, {
                        children: [
                            "点击下面某一个文件进入可视化界面，在编辑器修改该文件然后重新点击",
                            /*#__PURE__*/ jsx_runtime_.jsx(Text, {
                                code: true,
                                children: " build 按钮"
                            }),
                            "即可查看效果"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: ref,
                className: "w-full mt-4 flex-1",
                children: !!size?.height && /*#__PURE__*/ jsx_runtime_.jsx(DirectoryTree, {
                    height: size?.height,
                    itemHeight: 28,
                    className: "w-full",
                    icon: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
                    treeData: treeData[0].children,
                    onSelect: (_, { node  })=>{
                        const { key , type  } = node;
                        if (type === "file") {
                            router.push(key);
                            window.parent.postMessage({
                                isOpenFile: true,
                                path: "algorithm-visualizer/algorithms" + key
                            }, "*");
                        }
                    }
                })
            })
        ]
    });
};
/* harmony default export */ const index_page = (Home);


/***/ }),

/***/ 398:
/***/ ((module) => {

module.exports = require("ahooks");

/***/ }),

/***/ 725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [223], () => (__webpack_exec__(219)));
module.exports = __webpack_exports__;

})();